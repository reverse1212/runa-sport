import fs from 'fs'
import { requireUser } from '@/lib/auth.js'
import { backupPath } from '@/lib/backup.js'
import { logActivity } from '@/lib/log.js'

export const dynamic = 'force-dynamic'

export async function GET(_req, { params }) {
  const user = await requireUser('backups')
  const p = backupPath(params.file)
  if (!p) return new Response('No encontrado', { status: 404 })
  await logActivity(user, 'Descargar backup', 'Backup', null, params.file)
  return new Response(fs.readFileSync(p), { headers: { 'Content-Type': 'application/zip', 'Content-Disposition': `attachment; filename="${params.file}"` } })
}
