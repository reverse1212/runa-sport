import { requireUser } from '@/lib/auth.js'
import { listBackups } from '@/lib/backup.js'
import { fdate } from '@/lib/util.js'
import { ActionForm, ConfirmForm } from '@/components/admin/ActionForm.jsx'
import { makeBackup, deleteBackup, restoreBackupAction } from '@/lib/actions.js'

const size = (b) => (b > 1048576 ? `${(b / 1048576).toFixed(1)} MB` : `${Math.max(1, Math.round(b / 1024))} KB`)

export default async function Backups() {
  await requireUser('backups')
  const list = await listBackups()
  return (
    <>
      <h1>Backups</h1>
      <p>Cada backup guarda todos los datos (productos, stock, categorías, configuración, estadísticas, usuarios y actividad) y las imágenes en un archivo .zip dentro de la carpeta <code>backups</code> del proyecto. Guardá copias también fuera de esta computadora.</p>
      <div className="card" style={{ marginBottom: 16 }}>
        <p style={{ marginTop: 0 }}>Último backup: <b>{list[0] ? fdate(list[0].createdAt) : 'todavía no hiciste ninguno'}</b></p>
        <form action={makeBackup}><button className="abtn">Crear backup ahora</button></form>
      </div>
      <div className="tw"><table>
        <thead><tr><th>Archivo</th><th>Fecha</th><th>Tamaño</th><th>Creado por</th><th>Acciones</th></tr></thead>
        <tbody>{list.map((b) => (
          <tr key={b.filename}>
            <td>{b.filename}</td><td>{fdate(b.createdAt)}</td><td>{size(b.size)}</td><td>{b.by ?? '—'}</td>
            <td><div className="arow">
              <a className="abtn sm" href={`/admin/backups/${b.filename}`}>Descargar</a>
              <ActionForm action={restoreBackupAction} submit="Restaurar" className="arow"
                confirmMsg="Vas a REEMPLAZAR todos los datos e imágenes actuales por los de este backup. Antes se crea un backup automático del estado actual. ¿Continuar?">
                <input type="hidden" name="file" value={b.filename} />
                <input name="confirm" placeholder="Escribí RESTAURAR" aria-label="Confirmación" style={{ width: 150 }} autoComplete="off" />
              </ActionForm>
              <ConfirmForm action={deleteBackup.bind(null, b.filename)} message="¿Eliminar este archivo de backup?"><button className="abtn sm warn">Eliminar</button></ConfirmForm>
            </div></td>
          </tr>
        ))}{!list.length && <tr><td colSpan={5}>No hay backups.</td></tr>}</tbody>
      </table></div>
      <p><small>Al restaurar, se cierran todas las sesiones y vas a tener que volver a ingresar con un usuario que exista en el backup.</small></p>
    </>
  )
}
